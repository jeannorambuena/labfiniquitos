from flask import Blueprint

test_bp = Blueprint('test', __name__)


@test_bp.route('/hola')
def hola():
    return "¡Flask está funcionando y conectado!"
